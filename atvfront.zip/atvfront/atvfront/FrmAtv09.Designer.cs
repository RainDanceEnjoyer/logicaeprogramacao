﻿namespace atvfront
{
    partial class FrmAtv09
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl5 = new System.Windows.Forms.Label();
            this.lbl10 = new System.Windows.Forms.Label();
            this.lbl25 = new System.Windows.Forms.Label();
            this.lbl50 = new System.Windows.Forms.Label();
            this.lbl100 = new System.Windows.Forms.Label();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.txt5 = new System.Windows.Forms.TextBox();
            this.txt10 = new System.Windows.Forms.TextBox();
            this.txt25 = new System.Windows.Forms.TextBox();
            this.txt50 = new System.Windows.Forms.TextBox();
            this.txt100 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lblTotal = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(224)))), ((int)(((byte)(213)))));
            this.panel1.Controls.Add(this.txt100);
            this.panel1.Controls.Add(this.txt50);
            this.panel1.Controls.Add(this.txt25);
            this.panel1.Controls.Add(this.txt10);
            this.panel1.Controls.Add(this.txt5);
            this.panel1.Controls.Add(this.txt1);
            this.panel1.Controls.Add(this.lbl100);
            this.panel1.Controls.Add(this.lbl50);
            this.panel1.Controls.Add(this.lbl25);
            this.panel1.Controls.Add(this.lbl10);
            this.panel1.Controls.Add(this.lbl5);
            this.panel1.Controls.Add(this.lbl1);
            this.panel1.Location = new System.Drawing.Point(-1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(242, 454);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(172)))), ((int)(((byte)(143)))));
            this.panel2.Controls.Add(this.button1);
            this.panel2.Location = new System.Drawing.Point(240, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(569, 114);
            this.panel2.TabIndex = 1;
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(22, 32);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(35, 13);
            this.lbl1.TabIndex = 2;
            this.lbl1.Text = "label1";
            // 
            // lbl5
            // 
            this.lbl5.AutoSize = true;
            this.lbl5.Location = new System.Drawing.Point(22, 67);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(35, 13);
            this.lbl5.TabIndex = 3;
            this.lbl5.Text = "label2";
            // 
            // lbl10
            // 
            this.lbl10.AutoSize = true;
            this.lbl10.Location = new System.Drawing.Point(22, 101);
            this.lbl10.Name = "lbl10";
            this.lbl10.Size = new System.Drawing.Size(35, 13);
            this.lbl10.TabIndex = 4;
            this.lbl10.Text = "label3";
            // 
            // lbl25
            // 
            this.lbl25.AutoSize = true;
            this.lbl25.Location = new System.Drawing.Point(22, 137);
            this.lbl25.Name = "lbl25";
            this.lbl25.Size = new System.Drawing.Size(35, 13);
            this.lbl25.TabIndex = 5;
            this.lbl25.Text = "label4";
            // 
            // lbl50
            // 
            this.lbl50.AutoSize = true;
            this.lbl50.Location = new System.Drawing.Point(22, 172);
            this.lbl50.Name = "lbl50";
            this.lbl50.Size = new System.Drawing.Size(35, 13);
            this.lbl50.TabIndex = 6;
            this.lbl50.Text = "label5";
            this.lbl50.Click += new System.EventHandler(this.label5_Click);
            // 
            // lbl100
            // 
            this.lbl100.AutoSize = true;
            this.lbl100.Location = new System.Drawing.Point(22, 211);
            this.lbl100.Name = "lbl100";
            this.lbl100.Size = new System.Drawing.Size(35, 13);
            this.lbl100.TabIndex = 7;
            this.lbl100.Text = "label6";
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(25, 44);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(100, 20);
            this.txt1.TabIndex = 8;
            // 
            // txt5
            // 
            this.txt5.Location = new System.Drawing.Point(25, 83);
            this.txt5.Name = "txt5";
            this.txt5.Size = new System.Drawing.Size(100, 20);
            this.txt5.TabIndex = 9;
            // 
            // txt10
            // 
            this.txt10.Location = new System.Drawing.Point(25, 117);
            this.txt10.Name = "txt10";
            this.txt10.Size = new System.Drawing.Size(100, 20);
            this.txt10.TabIndex = 10;
            // 
            // txt25
            // 
            this.txt25.Location = new System.Drawing.Point(25, 153);
            this.txt25.Name = "txt25";
            this.txt25.Size = new System.Drawing.Size(100, 20);
            this.txt25.TabIndex = 11;
            // 
            // txt50
            // 
            this.txt50.Location = new System.Drawing.Point(25, 188);
            this.txt50.Name = "txt50";
            this.txt50.Size = new System.Drawing.Size(100, 20);
            this.txt50.TabIndex = 12;
            // 
            // txt100
            // 
            this.txt100.Location = new System.Drawing.Point(25, 227);
            this.txt100.Name = "txt100";
            this.txt100.Size = new System.Drawing.Size(100, 20);
            this.txt100.TabIndex = 13;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(172)))), ((int)(((byte)(143)))));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button1.Location = new System.Drawing.Point(109, 24);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(364, 59);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTotal.Location = new System.Drawing.Point(518, 269);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(10, 13);
            this.lblTotal.TabIndex = 2;
            this.lblTotal.Text = "-";
            // 
            // FrmAtv09
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(80)))), ((int)(((byte)(63)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "FrmAtv09";
            this.Text = "FrmAtv09";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl50;
        private System.Windows.Forms.Label lbl25;
        private System.Windows.Forms.Label lbl10;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txt100;
        private System.Windows.Forms.TextBox txt50;
        private System.Windows.Forms.TextBox txt25;
        private System.Windows.Forms.TextBox txt10;
        private System.Windows.Forms.TextBox txt5;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.Label lbl100;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblTotal;
    }
}