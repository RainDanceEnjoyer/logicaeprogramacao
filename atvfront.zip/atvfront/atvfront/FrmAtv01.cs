﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atvfront
{
    public partial class FrmAtv01 : Form
    {
        public FrmAtv01()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (txt1.Text == "" || txt1.Text == "" || txt3.Text == "")
            {
                MessageBox.Show("Insira um valor válido");
            }
            else
            {
                float Num1 = float.Parse(txt1.Text);
                float Num2 = float.Parse(txt2.Text);
                float Num3 = float.Parse(txt3.Text);
                float media;

                media = (Num1 + Num2 + Num3) / 3;

                lblMedia.Text = "" + media;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txt1.Text == "" || txt3.Text == "")
            {
                MessageBox.Show("Insira um valor válido");
            }
            else
            {
                float Num1 = float.Parse(txt1.Text);
                float Num3 = float.Parse(txt3.Text);
                float soma;


                soma = Num1 + Num3;

                lblSoma.Text = "" + soma;
            }


        }

        private void txt1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn3_Click(object sender, EventArgs e)
        {
            {
                if (txt1.Text == "" || txt1.Text == "" || txt3.Text == "")
                {
                    MessageBox.Show("Insira um valor válido");
                }
                else
                {
                    float Num1 = float.Parse(txt1.Text);
                    float Num2 = float.Parse(txt2.Text);
                    float Num3 = float.Parse(txt3.Text);
                    float percent1, percent2, percent3, total;

                    total = Num1 + Num2 + Num3;
                    percent1 = Num1 / total * 100;
                    percent2 = Num2 / total * 100;
                    percent3 = Num3 / total * 100;

                    lblPercent.Text = "Num1: " + percent1 + "%" + "\n" + "Num2: " + percent2 + "%" + "\n" + "Num3: " + percent3 + "%";
                } 
            }
        }
    }
}
    

