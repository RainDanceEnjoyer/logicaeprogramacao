﻿namespace atvfront
{
    partial class FrmAtv03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTotal = new System.Windows.Forms.Button();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblQuilo = new System.Windows.Forms.Label();
            this.txtQuilo = new System.Windows.Forms.TextBox();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // btnTotal
            // 
            this.btnTotal.Location = new System.Drawing.Point(50, 167);
            this.btnTotal.Name = "btnTotal";
            this.btnTotal.Size = new System.Drawing.Size(75, 23);
            this.btnTotal.TabIndex = 11;
            this.btnTotal.Text = "total";
            this.btnTotal.UseVisualStyleBackColor = true;
            this.btnTotal.Click += new System.EventHandler(this.btnTotal_Click);
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(47, 206);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(10, 13);
            this.lblTotal.TabIndex = 10;
            this.lblTotal.Text = "-";
            // 
            // lblQuilo
            // 
            this.lblQuilo.AutoSize = true;
            this.lblQuilo.Location = new System.Drawing.Point(47, 90);
            this.lblQuilo.Name = "lblQuilo";
            this.lblQuilo.Size = new System.Drawing.Size(31, 13);
            this.lblQuilo.TabIndex = 9;
            this.lblQuilo.Text = "Quilo";
            // 
            // txtQuilo
            // 
            this.txtQuilo.Location = new System.Drawing.Point(50, 118);
            this.txtQuilo.Name = "txtQuilo";
            this.txtQuilo.Size = new System.Drawing.Size(100, 20);
            this.txtQuilo.TabIndex = 7;
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.Chocolate;
            this.pnlTop.Location = new System.Drawing.Point(0, 0);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(800, 34);
            this.pnlTop.TabIndex = 14;
            // 
            // FrmAtv03
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnlTop);
            this.Controls.Add(this.btnTotal);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.lblQuilo);
            this.Controls.Add(this.txtQuilo);
            this.Name = "FrmAtv03";
            this.Text = "FrmAtv03";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTotal;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblQuilo;
        private System.Windows.Forms.TextBox txtQuilo;
        private System.Windows.Forms.Panel pnlTop;
    }
}