﻿namespace atvfront
{
    partial class FrmAtv02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtGas = new System.Windows.Forms.TextBox();
            this.txtGrana = new System.Windows.Forms.TextBox();
            this.lblGas = new System.Windows.Forms.Label();
            this.lblGrana = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.btnTotal = new System.Windows.Forms.Button();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // txtGas
            // 
            this.txtGas.Location = new System.Drawing.Point(40, 122);
            this.txtGas.Name = "txtGas";
            this.txtGas.Size = new System.Drawing.Size(100, 20);
            this.txtGas.TabIndex = 0;
            this.txtGas.TextChanged += new System.EventHandler(this.txtGas_TextChanged);
            // 
            // txtGrana
            // 
            this.txtGrana.Location = new System.Drawing.Point(40, 241);
            this.txtGrana.Name = "txtGrana";
            this.txtGrana.Size = new System.Drawing.Size(100, 20);
            this.txtGrana.TabIndex = 1;
            // 
            // lblGas
            // 
            this.lblGas.AutoSize = true;
            this.lblGas.Location = new System.Drawing.Point(37, 95);
            this.lblGas.Name = "lblGas";
            this.lblGas.Size = new System.Drawing.Size(94, 13);
            this.lblGas.TabIndex = 2;
            this.lblGas.Text = "Preço da Gasolina";
            this.lblGas.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblGrana
            // 
            this.lblGrana.AutoSize = true;
            this.lblGrana.Location = new System.Drawing.Point(37, 213);
            this.lblGrana.Name = "lblGrana";
            this.lblGrana.Size = new System.Drawing.Size(46, 13);
            this.lblGrana.TabIndex = 3;
            this.lblGrana.Text = "Dinheiro";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(37, 329);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(10, 13);
            this.lblTotal.TabIndex = 4;
            this.lblTotal.Text = "-";
            // 
            // btnTotal
            // 
            this.btnTotal.Location = new System.Drawing.Point(40, 290);
            this.btnTotal.Name = "btnTotal";
            this.btnTotal.Size = new System.Drawing.Size(75, 23);
            this.btnTotal.TabIndex = 5;
            this.btnTotal.Text = "total";
            this.btnTotal.UseVisualStyleBackColor = true;
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.Chocolate;
            this.pnlTop.Location = new System.Drawing.Point(0, -2);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(757, 34);
            this.pnlTop.TabIndex = 13;
            // 
            // FrmAtv02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(755, 409);
            this.Controls.Add(this.pnlTop);
            this.Controls.Add(this.btnTotal);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.lblGrana);
            this.Controls.Add(this.lblGas);
            this.Controls.Add(this.txtGrana);
            this.Controls.Add(this.txtGas);
            this.Name = "FrmAtv02";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.FrmAtv02_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtGas;
        private System.Windows.Forms.TextBox txtGrana;
        private System.Windows.Forms.Label lblGas;
        private System.Windows.Forms.Label lblGrana;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Button btnTotal;
        private System.Windows.Forms.Panel pnlTop;
    }
}