﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atvfront
{
    public partial class FrmAtv02 : Form
    {
        public FrmAtv02()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void FrmAtv02_Load(object sender, EventArgs e)
        {

        }

        private void txtGas_TextChanged(object sender, EventArgs e)
        {
       
        }

        private void btnTotal_Click(object sender, EventArgs e)
        {

        }
    }
}
