﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atvfront
{
    public partial class FrmAtv03 : Form
    {
        public FrmAtv03()
        {
            InitializeComponent();
        }

        private void btnTotal_Click(object sender, EventArgs e)
        {
            if (txtQuilo.Text == "")
            {
                MessageBox.Show("Insira um valor válido");
            }
            else
            {
                float Kg = float.Parse(txtQuilo.Text);
                float total;


                total = Kg * 34;

                lblTotal.Text = "" + total;
            }
        }
    }
}
