﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atvfront
{
    public partial class FrmAtv07 : Form
    {
        public FrmAtv07()
        {
            InitializeComponent();
        }

        private void FrmAtv07_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtP.Text == "" || txtM.Text == "" || txtG.Text == "")
            {
                MessageBox.Show("Insira um valor válido");
            }
            else
            {
                float P = float.Parse(txtP.Text);
                float M = float.Parse(txtM.Text);
                float G = float.Parse(txtG.Text);
                float totP = (12 * P);
                float totM = (16 * M);
                float totG = (22 * G);






                lblTotal.Text = "P" + totP + "\n" + "M" + totM + "\n" + "G" + totG;
            }
        }
    }
}

