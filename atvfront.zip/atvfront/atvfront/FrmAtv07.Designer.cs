﻿namespace atvfront
{
    partial class FrmAtv07
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Pnl1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Pnl2 = new System.Windows.Forms.Panel();
            this.txtM = new System.Windows.Forms.TextBox();
            this.txtP = new System.Windows.Forms.TextBox();
            this.txtG = new System.Windows.Forms.TextBox();
            this.lblP = new System.Windows.Forms.Label();
            this.lblM = new System.Windows.Forms.Label();
            this.lblG = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.lblTot = new System.Windows.Forms.Label();
            this.Pnl1.SuspendLayout();
            this.Pnl2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Pnl1
            // 
            this.Pnl1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(18)))), ((int)(((byte)(32)))));
            this.Pnl1.Controls.Add(this.lblG);
            this.Pnl1.Controls.Add(this.lblM);
            this.Pnl1.Controls.Add(this.lblP);
            this.Pnl1.Controls.Add(this.txtG);
            this.Pnl1.Controls.Add(this.txtM);
            this.Pnl1.Controls.Add(this.txtP);
            this.Pnl1.Controls.Add(this.panel2);
            this.Pnl1.Location = new System.Drawing.Point(0, 0);
            this.Pnl1.Name = "Pnl1";
            this.Pnl1.Size = new System.Drawing.Size(516, 289);
            this.Pnl1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(522, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(281, 289);
            this.panel2.TabIndex = 1;
            // 
            // Pnl2
            // 
            this.Pnl2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(167)))), ((int)(((byte)(30)))), ((int)(((byte)(52)))));
            this.Pnl2.Controls.Add(this.lblTot);
            this.Pnl2.Controls.Add(this.lblTotal);
            this.Pnl2.Location = new System.Drawing.Point(513, 0);
            this.Pnl2.Name = "Pnl2";
            this.Pnl2.Size = new System.Drawing.Size(287, 289);
            this.Pnl2.TabIndex = 1;
            // 
            // txtM
            // 
            this.txtM.Location = new System.Drawing.Point(33, 97);
            this.txtM.Name = "txtM";
            this.txtM.Size = new System.Drawing.Size(288, 20);
            this.txtM.TabIndex = 2;
            this.txtM.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtP
            // 
            this.txtP.Location = new System.Drawing.Point(33, 50);
            this.txtP.Name = "txtP";
            this.txtP.Size = new System.Drawing.Size(288, 20);
            this.txtP.TabIndex = 2;
            // 
            // txtG
            // 
            this.txtG.Location = new System.Drawing.Point(33, 144);
            this.txtG.Name = "txtG";
            this.txtG.Size = new System.Drawing.Size(288, 20);
            this.txtG.TabIndex = 3;
            // 
            // lblP
            // 
            this.lblP.AutoSize = true;
            this.lblP.ForeColor = System.Drawing.Color.White;
            this.lblP.Location = new System.Drawing.Point(30, 34);
            this.lblP.Name = "lblP";
            this.lblP.Size = new System.Drawing.Size(50, 13);
            this.lblP.TabIndex = 4;
            this.lblP.Text = "Pequeno";
            // 
            // lblM
            // 
            this.lblM.AutoSize = true;
            this.lblM.ForeColor = System.Drawing.Color.White;
            this.lblM.Location = new System.Drawing.Point(30, 81);
            this.lblM.Name = "lblM";
            this.lblM.Size = new System.Drawing.Size(36, 13);
            this.lblM.TabIndex = 5;
            this.lblM.Text = "Médio";
            // 
            // lblG
            // 
            this.lblG.AutoSize = true;
            this.lblG.ForeColor = System.Drawing.Color.White;
            this.lblG.Location = new System.Drawing.Point(30, 128);
            this.lblG.Name = "lblG";
            this.lblG.Size = new System.Drawing.Size(42, 13);
            this.lblG.TabIndex = 6;
            this.lblG.Text = "Grande";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.ForeColor = System.Drawing.Color.White;
            this.lblTotal.Location = new System.Drawing.Point(140, 116);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(0, 13);
            this.lblTotal.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(20)))), ((int)(((byte)(35)))));
            this.button1.Location = new System.Drawing.Point(324, 349);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(159, 38);
            this.button1.TabIndex = 3;
            this.button1.Text = "Resultado";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblTot
            // 
            this.lblTot.AutoSize = true;
            this.lblTot.ForeColor = System.Drawing.Color.Cornsilk;
            this.lblTot.Location = new System.Drawing.Point(140, 129);
            this.lblTot.Name = "lblTot";
            this.lblTot.Size = new System.Drawing.Size(10, 13);
            this.lblTot.TabIndex = 3;
            this.lblTot.Text = "-";
            // 
            // FrmAtv07
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(30)))), ((int)(((byte)(55)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Pnl2);
            this.Controls.Add(this.Pnl1);
            this.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.Name = "FrmAtv07";
            this.Text = "FrmAtv07";
            this.Load += new System.EventHandler(this.FrmAtv07_Load);
            this.Pnl1.ResumeLayout(false);
            this.Pnl1.PerformLayout();
            this.Pnl2.ResumeLayout(false);
            this.Pnl2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Pnl1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel Pnl2;
        private System.Windows.Forms.TextBox txtP;
        private System.Windows.Forms.TextBox txtM;
        private System.Windows.Forms.Label lblG;
        private System.Windows.Forms.Label lblM;
        private System.Windows.Forms.Label lblP;
        private System.Windows.Forms.TextBox txtG;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblTot;
    }
}