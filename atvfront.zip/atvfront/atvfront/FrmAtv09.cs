﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atvfront
{
    public partial class FrmAtv09 : Form
    {
        public FrmAtv09()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txt1.Text == "" && txt5.Text == "" && txt10.Text == "" && txt25.Text == "" && txt50.Text == "" && txt100.Text == "")
            {
                lblTotal.Text = "0";
            }
            else
            {
                if (txt1.Text == "" || txt5.Text == "" || txt10.Text == "" || txt25.Text == "" || txt50.Text == "" || txt100.Text == "")
                {
                    MessageBox.Show("Insira um valor válido");
                }
                else
                {
                    float one = float.Parse(txt1.Text);
                    float five = float.Parse(txt5.Text);
                    float ten = float.Parse(txt10.Text);
                    float twentyfive = float.Parse(txt25.Text);
                    float fifty = float.Parse(txt50.Text);
                    float hndrd = float.Parse(txt100.Text);

                    lblTotal.Text = "" + txt1.Text + "\n" + txt5.Text + "\n" +  txt10.Text + "\n" +  txt25.Text + "\n" +  txt50.Text + "\n" + txt100.Text;
                }
            }
        }
    }
}
