﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atvfront
{
    public partial class FrmAtv04 : Form
    {
        public FrmAtv04()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnResult_Click(object sender, EventArgs e)
        {
            if (txtBase.Text == "" || txtAlt.Text == "")
            {
                MessageBox.Show("Insira um valor válido");
            }
            else
            {
                float Base = float.Parse(txtBase.Text);
                float Alt = float.Parse(txtAlt.Text);
                float total;


                total = Base * Alt;

                lblTotal.Text = "" + total;
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
