﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atvfront
{
    public partial class FrmAtv08 : Form
    {
        public FrmAtv08()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtX1.Text == "" || txtX2.Text == "" || txtY1.Text == "" || txtY2.Text == "")
            {
                MessageBox.Show("Insira um valor válido");
            }
            else
            {
                float x1 = float.Parse(txtX1.Text);
                float x2 = float.Parse(txtX2.Text);
                float y1 = float.Parse(txtY1.Text);
                float y2 = float.Parse(txtY2.Text);
              
                
                double total;

                total = Math.Sqrt(((x2 - x1) * (x2 - x1))+((y2 - y1) * (y2 - y1))) ;
                lblTotal.Text = "" + total;
            }
        }
    }
}