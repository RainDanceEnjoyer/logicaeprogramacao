﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atvfront
{
    public partial class FrmAtv06 : Form
    {
        public FrmAtv06()
        {
            InitializeComponent();
        }

        private void lblBase_Click(object sender, EventArgs e)
        {

        }

        private void btnResult_Click(object sender, EventArgs e)
        {
            if (txtNum.Text == "")
            {
                MessageBox.Show("Insira um valor válido");
            }
            else
            {
                float Num = float.Parse(txtNum.Text);
              
                float total;

                total = Num * Num * Num;
               

                lblTotal.Text = "Área: " + total;
            }
        }
    }
}


