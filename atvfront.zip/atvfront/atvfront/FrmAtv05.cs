﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atvfront
{
    public partial class FrmAtv05 : Form
    {
        public FrmAtv05()
        {
            InitializeComponent();
        }

        private void btnResult_Click(object sender, EventArgs e)
        {
            if (txtBase.Text == "" || txtAlt.Text == "")
            {
                MessageBox.Show("Insira um valor válido");
            }
            else
            {
                float Base = float.Parse(txtBase.Text);
                float Alt = float.Parse(txtAlt.Text);
                float total1;
                float total2;


                total1 = Base * Alt;
                total2 = Base + Base + Alt + Alt;

                lblTotal.Text = "Área: " + total1 + "\n" + "Perímetro: " +total2;
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lblAltura_Click(object sender, EventArgs e)
        {

        }

        private void FrmAtv05_Load(object sender, EventArgs e)
        {

        }

        private void txtAlt_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }

