﻿namespace Whatsapp2
{
    partial class Whatsapp2
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Whatsapp2));
            this.btnGS = new System.Windows.Forms.Button();
            this.btnRS = new System.Windows.Forms.Button();
            this.btnDP = new System.Windows.Forms.Button();
            this.btnBW = new System.Windows.Forms.Button();
            this.btnXY = new System.Windows.Forms.Button();
            this.btnSM = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnGS
            // 
            this.btnGS.Location = new System.Drawing.Point(57, 86);
            this.btnGS.Name = "btnGS";
            this.btnGS.Size = new System.Drawing.Size(166, 61);
            this.btnGS.TabIndex = 0;
            this.btnGS.Text = "GS sets";
            this.btnGS.UseVisualStyleBackColor = true;
            this.btnGS.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnRS
            // 
            this.btnRS.Location = new System.Drawing.Point(57, 153);
            this.btnRS.Name = "btnRS";
            this.btnRS.Size = new System.Drawing.Size(166, 61);
            this.btnRS.TabIndex = 20;
            this.btnRS.Text = "RS sets";
            this.btnRS.UseVisualStyleBackColor = true;
            this.btnRS.Click += new System.EventHandler(this.btnRS_Click);
            // 
            // btnDP
            // 
            this.btnDP.Location = new System.Drawing.Point(57, 220);
            this.btnDP.Name = "btnDP";
            this.btnDP.Size = new System.Drawing.Size(166, 61);
            this.btnDP.TabIndex = 21;
            this.btnDP.Text = "DP sets";
            this.btnDP.UseVisualStyleBackColor = true;
            this.btnDP.Click += new System.EventHandler(this.btnDP_Click);
            // 
            // btnBW
            // 
            this.btnBW.Location = new System.Drawing.Point(57, 287);
            this.btnBW.Name = "btnBW";
            this.btnBW.Size = new System.Drawing.Size(166, 61);
            this.btnBW.TabIndex = 22;
            this.btnBW.Text = "BW sets";
            this.btnBW.UseVisualStyleBackColor = true;
            this.btnBW.Click += new System.EventHandler(this.btnBW_Click);
            // 
            // btnXY
            // 
            this.btnXY.Location = new System.Drawing.Point(57, 354);
            this.btnXY.Name = "btnXY";
            this.btnXY.Size = new System.Drawing.Size(166, 61);
            this.btnXY.TabIndex = 23;
            this.btnXY.Text = "XY sets";
            this.btnXY.UseVisualStyleBackColor = true;
            this.btnXY.Click += new System.EventHandler(this.btnXY_Click);
            // 
            // btnSM
            // 
            this.btnSM.Location = new System.Drawing.Point(57, 421);
            this.btnSM.Name = "btnSM";
            this.btnSM.Size = new System.Drawing.Size(166, 61);
            this.btnSM.TabIndex = 24;
            this.btnSM.Text = "SM sets";
            this.btnSM.UseVisualStyleBackColor = true;
            this.btnSM.Click += new System.EventHandler(this.btnSM_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(100, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 25);
            this.label1.TabIndex = 25;
            this.label1.Text = "Old Sets";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Whatsapp2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(300, 600);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSM);
            this.Controls.Add(this.btnXY);
            this.Controls.Add(this.btnBW);
            this.Controls.Add(this.btnDP);
            this.Controls.Add(this.btnRS);
            this.Controls.Add(this.btnGS);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Whatsapp2";
            this.Text = "Quagsire";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGS;
        private System.Windows.Forms.Button btnRS;
        private System.Windows.Forms.Button btnDP;
        private System.Windows.Forms.Button btnBW;
        private System.Windows.Forms.Button btnXY;
        private System.Windows.Forms.Button btnSM;
        private System.Windows.Forms.Label label1;
    }
}

