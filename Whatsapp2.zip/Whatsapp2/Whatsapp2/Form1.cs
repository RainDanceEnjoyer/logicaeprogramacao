﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Whatsapp2
{
    public partial class Whatsapp2 : Form
    {
        public Whatsapp2()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(" Belly Drum set" + Environment.NewLine + " Earthquake" + Environment.NewLine + " HP Rock" + Environment.NewLine + " Belly Drum" + Environment.NewLine + " Rest" + Environment.NewLine + " @Leftovers" );
        }

        private void btnRS_Click(object sender, EventArgs e)
        {
            MessageBox.Show(" Curse set" + Environment.NewLine + " Water Absorb" + Environment.NewLine + " Earthquake" + Environment.NewLine + " Curse" + Environment.NewLine + " HP rock / Surf / Ice beam" + Environment.NewLine + " Rest" + Environment.NewLine + " @Leftovers / Chesto Berry" + Environment.NewLine + " Brave / Sassy" + Environment.NewLine + " 252 HP / 64 Atk / 192 SpD" + Environment.NewLine );
        }

        private void btnDP_Click(object sender, EventArgs e)
        {
            MessageBox.Show(" SpD Set" + Environment.NewLine + " Water Absorb" + Environment.NewLine + " Earthquake" + Environment.NewLine + " Encore" + Environment.NewLine + " Toxic / Ice punch" + Environment.NewLine + " Recover" + Environment.NewLine + " @Leftovers" + Environment.NewLine + " Careful" + Environment.NewLine + " 252 HP / 56 Def / 200 SpD" + Environment.NewLine );
        }

        private void btnBW_Click(object sender, EventArgs e)
        {
            MessageBox.Show(" Def set" + Environment.NewLine + " Unaware" + Environment.NewLine + " Earthquake" + Environment.NewLine + " Scald" + Environment.NewLine + " Toxic / Encore" + Environment.NewLine + " Recover" + Environment.NewLine + " @Leftovers" + Environment.NewLine + " Relaxed" + Environment.NewLine + " 248 HP / 252 def / 8 SpD" + Environment.NewLine );
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnXY_Click(object sender, EventArgs e)
        {
            MessageBox.Show(" Unaware Defesive Wall" + Environment.NewLine + " Unaware" + Environment.NewLine + " Earthquake" + Environment.NewLine + " Scald" + Environment.NewLine + " Toxic / Encore" + Environment.NewLine + " Recover" + Environment.NewLine + " @Leftovers" + Environment.NewLine + " Relaxed" + Environment.NewLine + " 252 HP / 252 def / 4 SpD" + Environment.NewLine );
        }

        private void btnSM_Click(object sender, EventArgs e)
        {
            MessageBox.Show(" Unaware Defesive Wall" + Environment.NewLine + " Unaware" + Environment.NewLine + " Earthquake" + Environment.NewLine + " Scald" + Environment.NewLine + " Toxic / Encore" + Environment.NewLine + " Recover" + Environment.NewLine + " @Leftovers" + Environment.NewLine + " Relaxed" + Environment.NewLine + " 252 HP / 252 def / 4 SpD" + Environment.NewLine);
        }
    }
}
